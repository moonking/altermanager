// import {login ,logout,getInfo} from '@/api/login'

const user = {
  state: {
    name: '',
    states: 1
  },
  mutations: {
    SET_STATES: (state) => {
      state.states = false
    }
  },
  actions: {

  }
}

export default user
