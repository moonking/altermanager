<template>
  <div class="contentBox white-color aibms-color-bg non-border">222</div>
</template>

<script>
</script>

<style>
.contentBox {
  width: 90%;
  margin: 30px auto;
  line-height: 400px;
  text-align: center;
  border: 1px solid #fff;
  background: #fff;
}
</style>
