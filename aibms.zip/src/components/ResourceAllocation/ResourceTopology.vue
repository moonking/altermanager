<template>
  <div class="contentBox aibms-color-bg white-color non-border">管理各类邮件模板，可以定义模板数据结构及变量内容，提供API，调用方直接调用模板API，对相关变量进行替换，可以自定义变量</div>
</template>

<script>
</script>

<style>
.contentBox {
  margin: 10px;
  line-height: 400px;
  text-align: center;
  border: 1px solid #fff;
  background: #fff;
}
</style>
