<template>
  <div class="contentBox">组织管理页面,包括组织树，包括单位及部门，组织的增加，修改，删除，查询等</div>
</template>
<style>
.contentBox {
  margin: 10px;
  line-height: 400px;
  text-align: center;
  background: none;
  color: #fff;
}
</style>
