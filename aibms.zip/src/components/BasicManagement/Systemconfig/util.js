export const statementTypes = [
  { label: 'DDL', value: '1' },
  { label: 'DQL', value: '2' },
  { label: 'DML', value: '3' },
  { label: 'DCL', value: '4' },
  { label: 'DTL', value: '5' }
]

export const databaseList = [
  { label: 'Oracle', value: '1' },
  { label: 'MySQL', value: '2' },
  { label: 'SQL Server', value: '3' }
]
