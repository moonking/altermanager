<template>
    <div class="high-config">
        <router-view></router-view>
    </div>
</template>
<script>
export default {
  name: 'high-config',
  data () {
    return {

    }
  }
}
</script>
<style scoped lang="scss">

</style>
