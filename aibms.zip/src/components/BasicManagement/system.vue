<template>
  <div class="contentBox">纳入统一认证的系统列表，认证信息记录情况管理</div>
</template>

<script>
</script>

<style>
.contentBox {
  margin: 10px;
  line-height: 400px;
  text-align: center;
  border: 1px solid #fff;
  background: #fff;
}
</style>
