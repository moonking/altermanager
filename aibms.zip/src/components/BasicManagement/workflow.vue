<template>
  <div class="contentBox">
    <span>对平台工作流程进行管理，包括绘制流程图，节点配置，流程配置，可以对工作流程进行增删改查，可以对工作流实例进行管理，可以查询实例执行情况，统计相关信息，对发布，运维流程提供API支持</span>
  </div>
</template>

<script>
</script>

<style>
.contentBox {
  margin: 10px;
  line-height: 400px;
  text-align: center;
  border: 1px solid #fff;
  background: #fff;
}
</style>
