<template>
  <div class="contentBox">对平台用户相关操作进行日志记录，可以查询日志，统计相关数据，可以导出数据</div>
</template>
<style scoped>
.contentBox {
  margin: 10px;
  line-height: 200px;
  text-align: center;
  border: 1px solid #fff;
  background: #fff;
}
</style>
