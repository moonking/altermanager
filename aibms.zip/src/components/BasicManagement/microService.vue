<template>
  <div class="contentBox">服务注册，注销，服务发现，服务检测，服务列表</div>
</template>

<script>
</script>

<style scoped>
.contentBox {
  margin: 10px;
  line-height: 400px;
  text-align: center;
  border: 1px solid #fff;
  background: #fff;
}
</style>
