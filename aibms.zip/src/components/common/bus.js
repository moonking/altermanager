import Vue from 'vue'
// import router from '../../router'
// // 使用 Event Bus
// Vue.use(router)
const bus = new Vue()

export default bus
